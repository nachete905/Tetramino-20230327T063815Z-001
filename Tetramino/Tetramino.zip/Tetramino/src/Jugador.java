public class Jugador {
}
