public class Tetramino {
    private static String []tipos ={"Recta", "Zeta", "Zeta Invertida", "Ele", "Ele Invertida", "T", "Cuadrado"};
    private String tipo;
    private int vida = 4;
    private int posicionx;
    private int posiciony;

    public Tetramino(String tipo, int posicionx, int posiciony) {
        this.tipo = tipo;
        this.posicionx = posicionx;
        this.posiciony = posiciony;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public int getPosicionx() {
        return posicionx;
    }

    public void setPosicionx(int posicionx) {
        this.posicionx = posicionx;
    }

    public int getPosiciony() {
        return posiciony;
    }

    public void setPosiciony(int posiciony) {
        this.posiciony = posiciony;
    }
}


