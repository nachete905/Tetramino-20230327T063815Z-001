public class Main {
    public static void main(String [] args){
        Tablero tableroJugador = new Tablero();
        Tablero tableroPC = new Tablero();
    }

}