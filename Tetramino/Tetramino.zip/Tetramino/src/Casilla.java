public class Casilla {

    private boolean barco;
    private int fila;
    private int columna;
    public Casilla(int i, int j) {
        fila = i;
        columna = j;
    }

    public boolean isBarco() {
        return barco;
    }
    public void setBarco(boolean barco){
        this.barco = barco;
    }

    public int getFila() {
        return fila;
    }

    public void setFila(int fila) {
        this.fila = fila;
    }

    public int getColumna() {
        return columna;
    }

    public void setColumna(int columna) {
        this.columna = columna;
    }
}
