import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Tablero extends JFrame {

    private final int WIDTH = 600;
    private final int HEIGHT = 600;
    private final int ROWS = 10;
    private final int COLUMNS = 10;
    private int NUM_FICHAS;
    private final int MAX_NUM_FICHAS = 4;
    private JButton[][] buttons;
    private Casilla[][] casillas;
    private JComboBox<String> tetraminosComboBox;
    private JComboBox<String> rotacionesComboBox;

    public Tablero() {
        setTitle("Tablero de 10x10");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Crea las dos listas de selección
        tetraminosComboBox = new JComboBox<String>(new String[]{"Recta", "Zeta", "Zeta Invertida", "Ele", "Ele Invertida", "T", "Cuadrado"});
        rotacionesComboBox = new JComboBox<String>(new String[]{"0 grados", "90 grados", "180 grados", "270 grados"});

        // Agrega las listas de selección a un panel en la parte superior del tablero
        JPanel selectionPanel = new JPanel();
        selectionPanel.setLayout(new FlowLayout());
        selectionPanel.add(new JLabel("Seleccione un Tetramino:"));
        selectionPanel.add(tetraminosComboBox);
        selectionPanel.add(new JLabel("Seleccione una Rotación:"));
        selectionPanel.add(rotacionesComboBox);
        add(selectionPanel, BorderLayout.NORTH);

        // Crea el panel con GridLayout para los botones
        JPanel gridPanel = new JPanel(new GridLayout(ROWS, COLUMNS));
        // Crea la matriz de botones y las casillas correspondientes
        buttons = new JButton[ROWS][COLUMNS];
        casillas = new Casilla[ROWS][COLUMNS];
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLUMNS; j++) {
                casillas[i][j] = new Casilla(i, j);
                buttons[i][j] = new JButton();
                buttons[i][j].setName(Integer.toString(i) + Integer.toString(j));
                buttons[i][j].setPreferredSize(new Dimension(50, 50));
                buttons[i][j].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String tetraminoSeleccionado = (String) tetraminosComboBox.getSelectedItem();
                        String rotacionSeleccionada = (String) rotacionesComboBox.getSelectedItem();
                        JButton boton = (JButton) e.getSource();
                        String nombreBoton = boton.getName();
                        int fila = Integer.parseInt(nombreBoton.substring(0, 1));
                        int columna = Integer.parseInt(nombreBoton.substring(1, 2));
                        if (casillas[fila][columna].isBarco()) {
                            boton.setBackground(Color.RED);
                        } else {
                            boton.setBackground(Color.BLUE);
                            System.out.println(tetraminoSeleccionado);
                            System.out.println(rotacionSeleccionada);
                        }
                        boton.setEnabled(false);
                    }
                });
                gridPanel.add(buttons[i][j]); // Agrega el botón al panel de GridLayout
            }
        }

        add(gridPanel, BorderLayout.CENTER); // Agrega el panel de GridLayout al centro del JFrame

        setVisible(true);
        pack();
    }

}